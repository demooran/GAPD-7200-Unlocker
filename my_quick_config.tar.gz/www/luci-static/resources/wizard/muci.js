'use strict';'require baseclass';'require request';var CONTRACT={package:'wizard',section:'default',type:'wizard'};function normalizeValueForUci(field,value){if(field&&field.type==='flag')
return value===true||value===1||value==='1'||value==='true'||value==='on'?'1':'0';if(value==null)
return'';return String(value);}
function normalizeValuesForUci(fields,values){var normalized={};var list=fields&&fields.list?fields.list:(fields||[]);var source=values||{};for(var i=0;i<list.length;i++){var field=list[i];if(!field||!field.name)
continue;normalized[field.name]=normalizeValueForUci(field,source[field.name]);}
return normalized;}
function loadValues(uci){var values={};var sections=uci.sections(CONTRACT.package,CONTRACT.type)||[];var section=null;for(var i=0;i<sections.length;i++){if(sections[i]['.name']===CONTRACT.section){section=sections[i];break;}}
section=section||{};for(var key in section){if(!Object.prototype.hasOwnProperty.call(section,key)||key.charAt(0)==='.')
continue;values[key]=section[key];}
return values;}
function hasDefaultSection(uci){var sections=uci.sections(CONTRACT.package,CONTRACT.type)||[];for(var i=0;i<sections.length;i++)
if(sections[i]['.name']===CONTRACT.section)
return true;return false;}
function saveValues(uci,fields,values){var normalized=normalizeValuesForUci(fields,values);if(!hasDefaultSection(uci))
uci.add(CONTRACT.package,CONTRACT.type,CONTRACT.section);for(var key in normalized){if(!Object.prototype.hasOwnProperty.call(normalized,key)||key.charAt(0)==='.')
continue;uci.set(CONTRACT.package,CONTRACT.section,key,normalized[key]);}
return uci.save();}
function applyChanges(ui){if(ui&&ui.changes&&typeof ui.changes.apply==='function')
return ui.changes.apply();return Promise.resolve();}
function applyUnchecked(ui){if(typeof request!=='undefined'&&request&&typeof request.request==='function'&&typeof L!=='undefined'&&L&&L.env&&typeof L.url==='function'){return request.request(L.url('admin/uci','apply_unchecked'),{method:'post',query:{sid:L.env.sessionid,token:L.env.token}}).then(function(){return true;},function(){return true;});}
return applyChanges(ui);}
return baseclass.extend({contract:CONTRACT,normalizeValueForUci:normalizeValueForUci,normalizeValuesForUci:normalizeValuesForUci,loadValues:loadValues,saveValues:saveValues,applyChanges:applyChanges,applyUnchecked:applyUnchecked});