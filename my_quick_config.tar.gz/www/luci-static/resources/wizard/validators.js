'use strict';'require baseclass';function stateValue(state,key){var values=state&&state.values?state.values:{};var value=values[key];return value==null?'':String(value);}
function isEnabled(value){return value===true||value===1||value==='1'||value==='true'||value==='on';}
function matchesExpected(value,expected){if(Array.isArray(expected))
return expected.indexOf(value)!==-1;return value===expected;}
function byName(fields,name){for(var i=0;i<fields.length;i++)
if(fields[i].name===name)
return fields[i];return null;}
function networkFields(state){var mode=state&&state.setupMode?state.setupMode:stateValue(state,'MKSettings')||'AP';var pro=state&&state.uiMode==='pro';return mode==='PPPOE'?(pro?['IPADD','NETMASK','mk_is_Vlan','VLANID','PPPUSER','PPPPASS','PPPINTERFACE','BB_UNBRIDGE','BB_ALLOW_MGMT']:['IPADD','mk_is_Vlan','VLANID','PPPUSER','PPPPASS','PPPINTERFACE','BB_UNBRIDGE','BB_ALLOW_MGMT']):(pro?['IPADD','NETMASK','mk_is_Vlan','VLANID']:['IPADD','mk_is_Vlan','VLANID']);}
function broadbandPortInBridge(port){return['lan1','lan2','lan3','lan4','br-lan'].indexOf(String(port||''))!==-1;}
function wifi24Fields(state){return state&&state.uiMode==='pro'?['SSID2G','CH2G','2WKEYTYPE','2WIFIKEY']:['SSID2G','CH2G'];}
function modeFields(state){var mode=state&&state.setupMode?state.setupMode:stateValue(state,'MKSettings')||'AP';var pro=state&&state.uiMode==='pro';if(mode==='AP')
return pro?['SSID5G','CH5G','5WKEYTYPE','5WIFIKEY']:['SSID5G','CH5G'];if(mode==='MESH')
return pro?['MESHID','CH5G','MWKEYTYPE','MWIFIKEY','SSID5G','5WKEYTYPE','5WIFIKEY']:['MESHID','CH5G','MWKEYTYPE','MWIFIKEY'];if(mode==='APWDS')
return pro?['WDS_TY','APWDSSID','STAWDSSID','CH5G','HIDDEN','DWKEYTYPE','DWIFIKEY','SSID5G','5WKEYTYPE','5WIFIKEY']:['WDS_TY','APWDSSID','STAWDSSID','CH5G','HIDDEN','DWKEYTYPE','DWIFIKEY'];if(mode==='PPPOE')
return pro?['SSID5G','CH5G','5WKEYTYPE','5WIFIKEY']:['SSID5G','CH5G'];return[];}
function systemFields(){return['DoPASS','DPASS','RmoveOldConfig'];}
function protectionFields(){return['STOPREST','TYPREST','DelayREST'];}
function advancedFields(){return['CHWidte','No_WatchCat','WC_Preiod','WC_Timer','SVC_batmand','SVC_relayd','SVC_mwan3','SVC_eoip','SVC_wifisched'];}
function visibleFieldNames(state){return networkFields(state).concat(wifi24Fields(state)).concat(modeFields(state)).concat(systemFields()).concat(protectionFields()).concat(advancedFields());}
function isFieldVisible(field,state){var names;if(!field||!field.name)
return false;names=visibleFieldNames(state);if(names.indexOf(field.name)===-1)
return false;if(field.name==='VLANID')
return isEnabled(stateValue(state,'mk_is_Vlan'));if(field.name==='DPASS')
return isEnabled(stateValue(state,'DoPASS'));if(field.name==='2WIFIKEY')
return stateValue(state,'2WKEYTYPE')!=='none';if(field.name==='5WIFIKEY')
return stateValue(state,'5WKEYTYPE')!=='none';if(field.name==='MWIFIKEY')
return stateValue(state,'MWKEYTYPE')!=='none';if(field.name==='DWIFIKEY')
return stateValue(state,'DWKEYTYPE')!=='none';if(field.name==='TYPREST')
return!isEnabled(stateValue(state,'STOPREST'));if(field.name==='DelayREST')
return isEnabled(stateValue(state,'TYPREST'));if(field.name==='WC_Preiod')
return isEnabled(stateValue(state,'No_WatchCat'));if(field.name==='WC_Timer')
return stateValue(state,'WC_Preiod')==='custom';if(!field.depends)
return true;for(var key in field.depends){if(!Object.prototype.hasOwnProperty.call(field.depends,key))
continue;if(!matchesExpected(stateValue(state,key),field.depends[key]))
return false;}
return true;}
function isIPv4(value){var parts=String(value||'').split('.');if(parts.length!==4)
return false;for(var i=0;i<parts.length;i++){if(!/^\d+$/.test(parts[i]))
return false;if(Number(parts[i])<0||Number(parts[i])>255)
return false;}
return true;}
function addRequired(errors,value,message){if(String(value||'').trim()==='')
errors.push(message);}
function addLength(errors,value,min,max,label){var length=String(value||'').length;if(length<min||length>max)
errors.push(label+' '+_('يجب أن يكون بين')+' '+min+' '+_('و')+' '+max+' '+_('حرف.'));}
function addRange(errors,value,min,max,label){var text=String(value||'').trim();var number=Number(text);if(text===''||!/^\d+$/.test(text)||number<min||number>max)
errors.push(label+' '+_('يجب أن يكون رقمًا بين')+' '+min+' '+_('و')+' '+max+'.');}
function isKnownField(key,schema,fields){if(schema&&schema.fieldNames&&schema.fieldNames.indexOf(key)!==-1)
return true;return!!byName(fields||[],key);}
function validateField(key,value,state,schema,fields){var list=fields||[];var field=byName(list,key)||{name:key};var errors=[];var mode=state&&state.setupMode?state.setupMode:stateValue(state,'MKSettings')||'AP';if(!isKnownField(key,schema,list)||!isFieldVisible(field,state))
return{key:key,value:value,visible:false,errors:errors};value=value==null?'':String(value).trim();if(key==='IPADD'){addRequired(errors,value,_('عنوان IP مطلوب.'));if(value&&!isIPv4(value))
errors.push(_('عنوان IP يجب أن يكون IPv4 صحيحًا.'));}
else if(key==='NETMASK'){addRequired(errors,value,_('قناع الشبكة مطلوب.'));if(value&&!isIPv4(value))
errors.push(_('قناع الشبكة يجب أن يكون IPv4 صحيحًا.'));}
else if(key==='VLANID'&&isEnabled(stateValue(state,'mk_is_Vlan'))){addRange(errors,value,1,4094,'VLANID');}
else if(key==='SSID2G'){addRequired(errors,value,_('اسم شبكة 2.4G مطلوب.'));if(value)
addLength(errors,value,1,32,'SSID2G');}
else if(key==='SSID5G'){addRequired(errors,value,_('اسم شبكة 5G مطلوب.'));if(value)
addLength(errors,value,1,32,'SSID5G');}
else if(key==='2WIFIKEY'&&stateValue(state,'2WKEYTYPE')!=='none'){addRequired(errors,value,_('كلمة مرور 2.4G مطلوبة عند تفعيل الحماية.'));if(value)
addLength(errors,value,8,63,'2WIFIKEY');}
else if(key==='5WIFIKEY'&&stateValue(state,'5WKEYTYPE')!=='none'){addRequired(errors,value,_('كلمة مرور 5G مطلوبة عند تفعيل الحماية.'));if(value)
addLength(errors,value,8,63,'5WIFIKEY');}
else if(key==='MESHID'&&mode==='MESH'){addRequired(errors,value,_('معرف Mesh مطلوب.'));if(value)
addLength(errors,value,1,32,'MESHID');}
else if(key==='MWIFIKEY'&&stateValue(state,'MWKEYTYPE')!=='none'){addRequired(errors,value,_('كلمة مرور Mesh مطلوبة عند تفعيل الحماية.'));if(value)
addLength(errors,value,8,63,'MWIFIKEY');}
else if(key==='WDS_TY'&&mode==='APWDS'){addRequired(errors,value,_('نوع WDS مطلوب.'));}
else if(key==='APWDSSID'&&mode==='APWDS'&&stateValue(state,'WDS_TY')==='AWDS'){addRequired(errors,value,_('SSID مرسل WDS مطلوب.'));if(value)
addLength(errors,value,1,32,'APWDSSID');}
else if(key==='STAWDSSID'&&mode==='APWDS'&&stateValue(state,'WDS_TY')==='SWDS'){addRequired(errors,value,_('SSID مستقبل WDS مطلوب.'));if(value)
addLength(errors,value,1,32,'STAWDSSID');}
else if(key==='DWIFIKEY'&&stateValue(state,'DWKEYTYPE')!=='none'){addRequired(errors,value,_('كلمة مرور WDS مطلوبة عند تفعيل الحماية.'));if(value)
addLength(errors,value,8,63,'DWIFIKEY');}
else if(key==='PPPUSER'&&mode==='PPPOE'){addRequired(errors,value,_('اسم مستخدم PPPoE مطلوب.'));if(value)
addLength(errors,value,1,50,'PPPUSER');}
else if(key==='PPPPASS'&&mode==='PPPOE'){addRequired(errors,value,_('كلمة مرور PPPoE مطلوبة.'));if(value)
addLength(errors,value,1,50,'PPPPASS');}
else if(key==='PPPINTERFACE'&&mode==='PPPOE'){addRequired(errors,value,_('واجهة PPPoE مطلوبة.'));}
else if(key==='BB_UNBRIDGE'&&mode==='PPPOE'){var bbPort=stateValue(state,'PPPINTERFACE');if(broadbandPortInBridge(bbPort)&&!isEnabled(value))
errors.push(_('المنفذ')+' «'+bbPort+'» '+_('عضو في الجسر الرئيسي br-lan. لاستخدامه كمنفذ برودباند يجب إخراجه من الجسر أولًا — فعّل هذا الخيار (الموافقة على إخراج المنفذ) ثم احفظ.'));}
else if(key==='DPASS'&&isEnabled(stateValue(state,'DoPASS'))){addRequired(errors,value,_('كلمة مرور الجهاز مطلوبة عند تفعيل تغييرها.'));if(value)
addLength(errors,value,1,63,'DPASS');}
else if(key==='DelayREST'&&isEnabled(stateValue(state,'TYPREST'))){addRange(errors,value,5,600,'DelayREST');}
else if(key==='WC_Preiod'&&isEnabled(stateValue(state,'No_WatchCat'))){addRequired(errors,value,_('فترة WatchCat مطلوبة.'));}
else if(key==='WC_Timer'&&stateValue(state,'WC_Preiod')==='custom'){addRange(errors,value,5,1440,'WC_Timer');}
return{key:key,value:value,visible:true,errors:errors};}
function validateAll(state,schema,fields){var errors={};var values=state&&state.values?state.values:{};var list=fields||[];var names=visibleFieldNames(state);for(var i=0;i<names.length;i++){var field=byName(list,names[i]);var result;if(!field)
continue;result=validateField(field.name,values[field.name],state,schema,list);if(result.errors.length)
errors[field.name]=result.errors;}
return{valid:Object.keys(errors).length===0,errors:errors,warnings:buildWarnings(state,schema,list),schema:schema};}
function buildWarnings(state,schema,fields){var warnings=[];var mode=state&&state.setupMode?state.setupMode:stateValue(state,'MKSettings')||'AP';if(isEnabled(stateValue(state,'RmoveOldConfig')))
warnings.push(_('سيتم حذف الإعدادات السابقة قبل تطبيق الوضع الجديد.'));if(isEnabled(stateValue(state,'mk_is_Vlan')))
warnings.push(_('سيتم استخدام VLANID في إعدادات الشبكة.'));if(mode==='PPPOE'&&!stateValue(state,'PPPUSER'))
warnings.push(_('بيانات PPPoE ناقصة: اسم المستخدم فارغ.'));if(mode==='PPPOE'&&isEnabled(stateValue(state,'BB_UNBRIDGE')))
warnings.push(_('سيتم إخراج منفذ البرودباند من الجسر الرئيسي br-lan.'));if(mode==='PPPOE'&&isEnabled(stateValue(state,'BB_ALLOW_MGMT')))
warnings.push(_('سيتم فتح منافذ الإدارة (SSH/HTTP/HTTPS) من منفذ البرودباند/الوان — تأكد من ضبط كلمة مرور قوية.'));if(isEnabled(stateValue(state,'SVC_batmand'))||isEnabled(stateValue(state,'SVC_relayd'))||isEnabled(stateValue(state,'SVC_mwan3'))||isEnabled(stateValue(state,'SVC_eoip'))||isEnabled(stateValue(state,'SVC_wifisched')))
warnings.push(_('تم تفعيل خدمات نظام إضافية من قسم المتقدم.'));if(isEnabled(stateValue(state,'STOPREST')))
warnings.push(_('زر الفورمات معطل.'));if(isEnabled(stateValue(state,'No_WatchCat')))
warnings.push(_('WatchCat مفعّل.'));if(isEnabled(stateValue(state,'HIDDEN')))
warnings.push(_('بث WDS مخفي.'));return warnings;}
return baseclass.extend({buildWarnings:buildWarnings,validateAll:validateAll,validateField:validateField,isFieldVisible:isFieldVisible});